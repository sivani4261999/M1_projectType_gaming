#include"stdio.h"
#include "regist.h"

// Patients already registered list is given as input for verification
// pd stands for patient details
int existregist(){
    pd[1].age=123;
    pd[1].aadhar=123;
    pd[1].ph_number=123;
    pd[1].secret_code=123;
    pd[1].vaccine_type=1;
    pd[1].vaccine_doses=1;
    return 0;
}
